#define small_colon_width 2
#define small_colon_height 7
static unsigned char small_colon_bits[] = {
   0x00, 0x03, 0x03, 0x00, 0x03, 0x03, 0x00};

